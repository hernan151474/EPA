#!/bin/bash

cd $(dirname $0)/bin
./startup.sh $*

